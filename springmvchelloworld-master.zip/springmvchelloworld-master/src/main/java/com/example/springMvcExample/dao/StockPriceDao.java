package com.example.springMvcExample.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springMvcExample.model.StockPrice;

public interface StockPriceDao extends JpaRepository<StockPrice, Integer>{

}
