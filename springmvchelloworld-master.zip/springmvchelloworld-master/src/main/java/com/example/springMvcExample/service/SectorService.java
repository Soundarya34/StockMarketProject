package com.example.springMvcExample.service;

import java.sql.SQLException;
import java.util.List;

import com.example.springMvcExample.model.Company;
import com.example.springMvcExample.model.Sector;

public interface SectorService {

	public boolean insertSector(Sector sector ) throws SQLException;
	
	public List<Sector> getSectorList() throws SQLException;
	
	
}
