package com.example.springMvcExample.controller;

import java.sql.SQLException;
import java.util.List;

import com.example.springMvcExample.model.Company;
import com.example.springMvcExample.model.StockExchange;

public interface StockExchangeController {

	public boolean insertStockExchange(StockExchange stockExchange) throws SQLException;

	public boolean updateStockExchange(StockExchange stockExchange) throws SQLException;

	public List<StockExchange> getStockExchangeList() throws Exception;
}
