package com.example.springMvcExample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springMvcExample.dao.StockPriceDao;
import com.example.springMvcExample.model.StockPrice;

@Service
public class StockPriceServiceImpl implements StockPriceService {

	@Autowired
	private StockPriceDao stockPriceDao;
	
	@Override
	public List<StockPrice> getStockList() {
		// TODO Auto-generated method stub
		return stockPriceDao.findAll();
	}

	@Override
	public void insertStock(StockPrice stockPrice) {
		stockPriceDao.save(stockPrice);
		
	}
	
	   
	

}
